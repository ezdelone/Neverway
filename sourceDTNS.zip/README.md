// ============================================================
// neverwin.dll — reconstructed source
// README.md — index, address map, build notes
// ============================================================
# neverwin.dll — reconstructed source (Double Tap + NoSpread)

**Это реконструкция логики из статического реверса (IDA 9.3 headless), не оригинальный
исходный код. Псевдокод восстановлен вручную из декомпила: имена восстановлены по
строкам/структуре, часть хелперов оставлена как шимы с оригинальными адресами.**

## Файлы

| Файл | Что внутри | Оригинальные функции |
|---|---|---|
| `schema.h` | runtime-резолвер schema-офсетов + кэши | sub_18043B6A0, sub_18038EAF0, BSS-группа 0x181111C9C..CC8 |
| `double_tap.cpp` | стейт-машина DT, тикбейс-шифт, фаер-гейт, recharge, индикатор | sub_18026A790, sub_18043B910, sub_180474850, sub_180474680, sub_18047B4A0(case 10), sub_1800C24C0, sub_1801CB5F0 |
| `remove_spread.cpp` | солвер спреда: tier0 RNG mirror, сигскан паттернов, конфиг-пак | sub_18042D730, sub_18042D5E0, sub_1804707A0 |
| `rage_weapon.h` | структуры: shot ring 150x2000, weapon window, shot_record | unk_180C3DF70, layout из sub_18047B4A0/sub_180474680 |
| `telemetry.cpp` | wl_shots.log + локальный JITTER-монитор | sub_18046E7D0, sub_18020E390, sub_18020EEB0 |

## Ключевые адреса

```
-- конфиг-глобалы (.data)
0x18095CD6C  ragebot.history
0x18095CD70  ragebot.delay_shot
0x18095CD74  ragebot.future_ticks
0x18095CD78  ragebot.remove_spread_mode      0=off 1=seed check 2=full
0x18095CD7C  ragebot.duck_peek_assist
0x18095CD7D  ragebot.double_precision
0x18095CD7E  ragebot.double_tap
0x18095CD80  ragebot.remove_spread
0x18095CEDD  indicators.double_tap_hide_if_restricted
0x180920FDC  antiaim.hide_shots (+12 байт опций)

-- DT-стейт (BSS)
0x181111C58  u16 state    HI=active; 0x0100 fired / 0x0101 recharge / 0x0102 forced
0x181111C5A  u8  recharge mode (1|2)
0x181111C5C  s32 recharge tick counter
0x181111C60  u8  latch "shift недоступен"
0x181111A00  s32[150] кольцо тиков шифтованных выстрелов (cmd % 150)

-- NS-состояние
0x1811118E0  паттерн-таблица (из сигскана)
0x1811118E8  паттерн-lookup (из сигскана)
0x1811118F0  tier0 RNG stream instance
0x180CD1AC5  latch: "no pattern pellets"
0x180CD1AC6  latch: rng resolved
0x180CD1AC7  latch: "game seed function missing"
0x180CD1B2C  latch: schema ns group
0x180CD1B2D  latch: pattern scan done

-- сигнатура спред-паттернов (.text окна 1536 байт от qword_180961CA8)
48 8D 0D ?? ?? ?? ?? 45 03 ?? CC E8
  -> table  = rip+disp (инстр 1)
  -> lookup = rip+disp (инстр 2, +15)

-- tier0 RNG
?SetSeed@?$CUniformRandomStreamImpl@VCThreadNullMutex@@@@QEAAXH@Z
?RandomFloat@?$CUniformRandomStreamImpl@VCThreadNullMutex@@@@QEAAMMM@Z
```

## Схема работы Double Tap

```
createmove:
  dt_fire_allowed()          -- sub_180474850
    ├─ блок если state&0xFD != 0 (идёт recharge)
    ├─ отказ для ножа(31)/C4(64), при latch_no_shift
    ├─ prepare_weapon_window()             -- sub_1804741F0 (cycle time)
    └─ shot_window()                       -- sub_180474680 (кольцо 32 тиков, cycle time check)
  если разрешили:
    apply_tickbase_shift(pawn, phase)      -- sub_18026A790
      tickbase = min(current, base + tickgame - 3)
    dt::state = 0x0100, ring[cmd%150] = next_attack_tick

net_update_end / tick:                       -- sub_18043B910
  сравнить m_nNextPrimaryAttackTick с записанным
  сервер подтвердил шифт  -> state=0x0100++, recharge_cnt++
  обычный ритм вернулся   -> state=0x0101, отсчёт до -3 тиков, потом clear
  clear: state=0, cnt=0

resolver (каждый выстрел):                   -- sub_18047B4A0
  status==10 (damage rejection) и |tickbase - next_attack| <= 4 и DT on
    -> state=0x0102 (форс-recharge, mode 2)
```

## Схема работы Remove Spread

```
pack_weapon_cfg()                            -- sub_1804707A0
  mode==2 (Full): гасит seed-зависимые подопции

solve_no_spread()                            -- sub_18042D730
  1. init_rng():      tier0.dll -> SetSeed/RandomFloat (иначе ran1)
  2. scan_pattern():  сиг 48 8D 0D ?? ?? ?? ?? 45 03 ?? CC E8 -> таблицы паттернов
  3. schema: m_nNumBullets, m_pGameSceneNode, m_flAbsScale
  4. pellet_center = shoot_pos + bbox_center * abs_scale
  5. candidate_search()                      -- sub_18042B640
     перебор направлений с RNG-mirror:
       mode Full:      ищем направление с нулевым отклонением
       mode SeedCheck: проверяем попадание при данном hitchance
  6. out: angles + tick
```

## Шимы (не восстановлены 1:1, оставлены как точки входа)

`schema_offset`, `get_local_controller/pawn`, `entity_from_handle`, `read_u32/f32/i32/ptr`,
`tickgame_ticks`, `weapon_type_of`, `weapon_vdata_of`, `candidate_search`,
`engine_pattern_lookup`, `compute_shot_seed`, `recompute_attack_timing`,
`next_attack_tick_of`, `current_attack_tick_of`, `wrap_time`, `ring_time`,
`log_shot_status`, `find_shot_slot`, `game_state`, `in_freeze_period` —
все они в бинарнике сидят на конкретных адресах (см. REPORT.md в корне
`neverwin_work`), при сборке в хук-модуль заменяются прямыми вызовами движка.

## Не восстановлено (за пределами скоупа)

- `sub_18042B640` — внутренний цикл перебора кандидатов NS (крупный, требует
  отдельного прогона; интерфейс и vtable-коллбеки восстановлены).
- Lua-движок, UI (ImGui-слой), конфиг-файловая часть, skin changer, ESP —
  к DT/NS отношения не имеют.
