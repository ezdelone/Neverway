// ============================================================
// neverwin.dll — reconstructed source
// double_tap.cpp — tickbase shift exploit state machine
// Recovered from: sub_18026A790 (shift), sub_18043B910 (update),
// sub_180474850 (gate), sub_18047B4A0 (resolve/recharge),
// sub_1800C24C0 (indicator), sub_1801CB5F0 (reset)
// ============================================================
#include "schema.h"
#include <algorithm>
#include <cmath>

// ---- config (rage section) --------------------------------
namespace cfg {
    inline bool   ragebot_enabled      = false; // byte_18095723C
    inline bool   double_tap           = false; // byte_18095CD7E
    inline bool   double_precision     = false; // byte_18095CD7D
    inline int    future_ticks         = 0;     // dword_18095CD74
    inline bool   duck_peek_assist     = false; // byte_18095CD7C
    inline bool   remove_spread        = false; // unk_18095CD80
    inline int    remove_spread_mode   = 0;     // dword_18095CD78 0=off 1=seed 2=full
    inline int    history              = 0;     // dword_18095CD6C
    inline bool   automatic_fire       = false; // byte_18095CD44
    inline bool   indicators_dt_hide   = false; // byte_18095CEDD
    inline bool   limiters             = false; // byte_18095CD45
    inline bool   selftrack            = false; // byte_18095CD60
}

// ---- DT state (BSS globals in the DLL) --------------------
namespace dt {
    inline uint16_t state        = 0;    // word_181111C58: HI=active, LO=phase
    inline uint8_t  recharge_mode = 0;   // byte_181111C5A
    inline int32_t  recharge_cnt  = 0;   // dword_181111C5C
    inline bool     latch_no_shift= false; // byte_181111C60
    inline bool     latch_active  = false; // byte_181111C68
    inline int32_t  shift_tick_ring[150];  // dword_181111A00[cmd % 150]

    constexpr uint16_t ST_FIRED      = 0x0100; // shifted shot sent, recharging
    constexpr uint16_t ST_RECHARGE   = 0x0101; // recharge after normal shot
    constexpr uint16_t ST_FORCED     = 0x0102; // forced recharge after rejection

    inline bool active()        { return (state & 0xFF00) != 0; }
    inline bool active_hi()     { return (state >> 8) != 0; }
    inline bool phase_fired()   { return (state & 0x00FF) == 0x00; } // state & 0xFD == 0
    inline void reset() {                 // == tail of sub_1801CB5F0
        state = 0; recharge_cnt = 0; latch_active = false;
    }

    inline int* ring_slot(int cmd) { return &shift_tick_ring[((cmd % 150) + 150) % 150]; }
}

// ---- engine shims (thin wrappers over game interfaces) -----
int      tickgame_ticks();                       // sub_18053FC00: current world tick int part
float    tickgame_frac();                        // fractional part of world time
void*    get_local_controller();                 // CCSPlayerController
void*    get_local_pawn();                       // C_CSPlayerPawn
void*    entity_from_handle(uint32_t h);
uint32_t read_u32(uintptr_t base, uintptr_t off);
float    read_f32(uintptr_t base, uintptr_t off);
void     write_i32(uintptr_t base, uintptr_t off, int32_t v);
uintptr_t weapon_vdata(uintptr_t weapon);

// ============================================================
// CORE: tickbase shift  (sub_18026A790)
// phase != 0  -> write shifted tickbase unclamped
// phase == 0  -> clamp:  tickbase = min(current, base + tickgame - 3)
//                also clamps the sub-tick field when weapon vdata
//                reports the "uses new attack pipeline" bit
// ============================================================
bool apply_tickbase_shift(uintptr_t pawn, bool phase)
{
    if (!pawn) return false;
    if (!offsets::dt_tickbase_field) return false;

    uintptr_t field = pawn + offsets::dt_tickbase_field;
    int controller_tickbase = 0;
    if (auto* ctrl = get_local_controller(); ctrl && offsets::m_nTickBase)
        controller_tickbase = read_u32((uintptr_t)ctrl, offsets::m_nTickBase);

    if (phase) {                                   // raw write (phase 1)
        write_i32(field, 0, controller_tickbase);
        return true;
    }

    if (uintptr_t scene = read_ptr(pawn, offsets::m_pGameSceneNode)) { // vdata side for subtick
        // original also reads a vdata bool here (dword_180CFA100/104 group)
    }
    int clamp_limit = controller_tickbase + tickgame_ticks() - 3;
    int current     = read_i32(field, 0);
    write_i32(field, 0, std::min(current, clamp_limit));

    if (int sub = offsets::dt_subtick_field) {     // second clamp target when engine bit set
        uintptr_t f2 = pawn + sub;
        int limit2 = controller_tickbase + tickgame_ticks() - 3;
        int cur2   = read_i32(f2, 0);
        if (cur2 > limit2) write_i32(f2, 0, limit2);
    }
    return true;
}

// ============================================================
// STATE UPDATE  (sub_18043B910)
// Called per usercmd. Compares the weapon's next-attack tick with
// what we recorded when the shifted shot went out; opens/closes
// the recharge window and latches 'definitely shifted' state.
// ============================================================
void dt_state_update(uintptr_t weapon_services_owner, uint32_t* cmd_block)
{
    offsets::init_weapon_group();

    int  next_attack_tick = read_u32(weapon_services_owner, offsets::m_nNextPrimaryAttackTick);
    int  recorded         = cmd_block[217];
    if (next_attack_tick == recorded)
        return;

    int weapon_type = weapon_type_of(weapon_services_owner); // sub_18043B8B0 via m_nSubclassID->vdata
    if (weapon_type < 0)
        return;

    int shifted_shot_tick = *dt::ring_slot(*cmd_block); // dword_181111A00[cmd%150]
    int local_tickbase    = 0;
    if (auto* ctrl = get_local_controller())
        local_tickbase = read_u32((uintptr_t)ctrl, offsets::m_nTickBase);

    if (next_attack_tick > recorded) {
        // ---- shot actually consumed: server accepted a shifted command ----
        if (dt::active() && dt::phase_fired()) {          // HI set, LO == 1? (== 1 check)
            if (next_attack_tick != shifted_shot_tick)
                return;
            if (!weapon_type)
                return;
            // fallthrough to full clear below
        } else {
            if (uintptr_t vdata = weapon_vdata_of(weapon_services_owner))
                if (offsets::m_flCycleTime) read_f32(vdata, offsets::m_flCycleTime); // touch/cache

            if (next_attack_tick != local_tickbase + tickgame_ticks() - 3)
                return;

            if (!dt::active()) {
                if (dt::recharge_cnt > 0 && dt::recharge_mode == 0) {
                    dt::recharge_mode = 0;
                    dt::recharge_cnt  = 1;
                } else {
                    ++dt::recharge_cnt;
                }
                dt::state = dt::ST_FIRED;      // 0x0100
            }
            if (weapon_type) return;
            dt::latch_no_shift = true;
            return;
        }
    }
    // ---- walk-back: attack tick moved backwards/other direction ----
    if (dt::active() && (dt::state & 0x00FF) == 0) {   // HI set, LO==0
        if (next_attack_tick != shifted_shot_tick)
            return;
        if (!weapon_type) {
            dt::latch_no_shift = false;
            return;
        }
    } else if (next_attack_tick == local_tickbase) {
        if (!dt::active()) {
            if (dt::recharge_cnt > 0 && dt::recharge_mode == 1)
                ++dt::recharge_cnt;
            else {
                dt::recharge_mode = 1;
                dt::recharge_cnt  = 1;
            }
            dt::state = dt::ST_RECHARGE;   // 0x0101
        }
        if (!weapon_type)
            dt::latch_no_shift = true;
    }
}

// full-clear helper used by both branches (the LABEL_36 path)
static void dt_state_clear()
{
    dt::state         = 0;   // writes (uint16*)&C58 + 1 = 0 -> clears HI+LO
    dt::recharge_cnt  = 0;
}

// ============================================================
// FIRE GATE  (sub_180474850)
// Decides whether THIS cmd may fire using the shifted tickbase.
// ============================================================
bool dt_fire_allowed(uintptr_t weapon, uint32_t cmd_num, bool want_shift)
{
    if (!read_ptr(weapon, 1968))        // no vdata -> no shift
        return false;

    uint16_t wtype = read_u16(weapon, 1976);
    const bool block = (dt::state & 0x00FD) != 0 || !dt::active();

    if (block) {
        recompute_attack_timing(weapon);              // sub_1804742A0 side effects
    } else {
        if (recompute_attack_timing(weapon) || wtype == 31 /*knife*/ || dt::latch_no_shift)
            return false;
    }

    if (!want_shift || wtype == 64 /*c4*/
        || (read_i32(weapon, 884) < 2 && (wtype == 31 || recompute_attack_timing(weapon))))
        return false;

    prepare_weapon_window(weapon, cmd_num);           // sub_1804741F0: cache cycle time

    auto [next_tick, next_frac] = next_attack_tick_of(weapon); // sub_180474460 on +348
    auto [cur_tick,  cur_frac]  = current_attack_tick_of(weapon);

    // firing only allowed when the next-attack time is NOT in the future
    if (cur_tick == next_tick ? cur_frac > next_frac : cur_tick < next_tick)
        return false;

    return can_fire_at(weapon, cmd_num, nullptr);     // sub_180474680 window check
}

// ============================================================
// SHOT WINDOW  (sub_180474680)
// Returns the last-fire (tick,frac) from the 32-slot history ring
// if a new shot at the requested time is legal (cycle time check).
// ============================================================
bool shot_window(uintptr_t weapon, int secondary, int64_t* out_last)
{
    const int tick_ofs = secondary ? offsets::WPN_ATK2_TICK : offsets::WPN_ATK1_TICK;
    const int frac_ofs = secondary ? offsets::WPN_ATK2_FRAC : offsets::WPN_ATK1_FRAC;

    int   base_tick = read_i32(weapon, tick_ofs);
    float base_frac = read_f32(weapon, frac_ofs);
    float extra     = 0.0f;
    auto [wt, wf]   = wrap_time(weapon + 856, &extra);   // fractional world time

    float target_frac = base_frac + wf; if (target_frac >= 1.0f) target_frac -= 1.0f;
    int   target_tick = base_tick + (int)wf + 1 - (target_frac < base_frac + wf ? 0 : 1);
    // (decompiler noise folded: +2 when wrap else +1)

    int   count = read_i32(weapon, offsets::WPN_TICK_COUNT);
    int64_t last = 0;
    if (count > 0) {
        int head = read_i32(weapon, offsets::WPN_TICK_HEAD);
        auto [lt, lf] = ring_time(weapon, (head + count - 1));
        last = pack64(lt, lf);
    }

    const bool before_last = (int32_t)(last >> 32) == target_tick
        ? wf > (float)(int32_t)last
        : (int32_t)(last >> 32) < target_tick;
    if (!before_last)
        return false;                     // still inside previous shot's cycle time

    const int prev_tick = target_tick - (target_frac < base_frac ? 2 : 3);
    const bool before_prev = (int32_t)(last >> 32) == prev_tick
        ? wf > (float)(int32_t)last
        : (int32_t)(last >> 32) < prev_tick;

    if (before_prev) { *out_last = pack64(prev_tick, target_frac); }
    else             { *out_last = last; }
    return true;
}

// ============================================================
// SHOT RESOLUTION  (sub_18047B4A0, case 10)
// Damage rejected by the server with DT enabled -> force recharge
// so the next shifted shot comes up immediately.
// ============================================================
void on_shot_resolved(shot_record_t* rec)
{
    if (rec->suppressed) return;
    const int status = rec->status;       // +78*4
    if (status == 1) return;              // plain hit

    switch (status) {
        case 3:  /* prediction / spread / hitchance */ break;
        case 4:  /* lagcomp / occlusion */             break;
        case 5:  /* extrapolation */                   break;
        case 6:  /* death */                           break;
        case 7:  /* player death */                    break;
        case 8:  /* event timeout */                   break;
        case 9:  /* unregistered shot */               break;
        case 10: /* damage rejection */                break;
    }
    log_shot_status(rec, status);         // sub_180470370 + chat/log strings

    if (status != 10)
        return;

    const bool dt_enabled = cfg::double_tap;           // byte_18095CD7E
    int weapon_handle     = rec->weapon_handle;        // a1+3*4
    refresh_weapon_schema();                           // sub_18043B6A0
    if (weapon_handle == -1) return;

    auto* weapon = (uintptr_t)entity_from_handle(weapon_handle);
    if (!weapon) return;

    uintptr_t vdata = 0;
    if (weapon && offsets::m_nSubclassID) {
        uintptr_t sid = read_ptr(weapon, offsets::m_nSubclassID + 8);
        if (is_valid_ptr(sid)) vdata = sid;
    }
    if (!vdata && !weapon) return;
    if (!vdata) return;

    int local_tickbase = 0;
    if (auto* ctrl = get_local_controller())
        local_tickbase = read_u32((uintptr_t)ctrl, offsets::m_nTickBase);
    int next_attack = read_u32(weapon, offsets::m_nNextPrimaryAttackTick);
    if (offsets::m_flCycleTime)
        read_f32(weapon_vdata_of(weapon), offsets::m_flCycleTime);

    int delta = local_tickbase - next_attack + tickgame_ticks();
    int absd  = std::abs(delta);

    if (absd <= 4 && dt_enabled) {
        if (!dt::active_hi()) {                        // !HIBYTE(word_181111C58)
            if (dt::recharge_cnt > 0 && dt::recharge_mode == 2) {
                ++dt::recharge_cnt;
                dt::state = 0x0102;                    // word = 258
            } else {
                dt::recharge_mode = 2;
                dt::recharge_cnt  = 1;
            }
        }
    } else {
        dt::state &= 0x00FF;                           // *((uint16*)&C58+1) = 0
        dt::recharge_cnt = 0;
    }
}

// ============================================================
// INDICATOR  (sub_1800C24C0) — computes the DT charge 0..1
// ============================================================
dt_indicator_t dt_indicator()
{
    dt_indicator_t out{};
    if (!cfg::ragebot_enabled
        || (game_state() == 2)
        || (game_state() == 1 && in_freeze_period())
        || !cfg::double_tap) {
        out.reason = 1; return out;
    }
    auto* pawn = get_local_pawn();
    if (!pawn || !offsets::m_iShotsFired
        || read_u32(pawn, offsets::m_iShotsFired) - 1 > 999) {
        out.reason = 2; return out;
    }
    auto* weapon = active_weapon_of(pawn);              // sub_1800C04A0
    if (!weapon || !weapon_vdata_of(weapon)
        || read_u16(weapon, 1976) == 31
        || read_u16(weapon, 1976) == 64
        || read_f32(weapon_vdata_of(weapon), offsets::m_flCycleTime) > 6.0f) {
        out.reason = 3; return out;
    }

    int cmd = current_cmd_number();
    shot_slot_t* slot = find_shot_slot(cmd);            // unk_180C3DF70 ring
    if (!slot) { out.reason = 4; return out; }
    if (slot->charge <= 1) {                            // prev slot same check
        out.reason = 4; return out;
    }

    const bool restricted =
        ((dt::state & 0x00FD) == 0 && dt::active_hi())
        && (weapon_vdata_flag(weapon) || dt::latch_active); // word_181111C58 bit layout

    if (restricted && cfg::indicators_dt_hide) {
        out.reason = 5; return out;                     // hide entirely
    }

    // charge from tick deltas (decomp: values packed as 1/16 fractions,
    // delta of next-attack vs current, normalized into 0..1)
    const int   next_attack = read_u32(weapon, offsets::m_nNextPrimaryAttackTick);
    const float delta       = (float)(next_attack - current_tick())
                            - frac_delta(slot, weapon);   // (v51*0.015625)+(v52*0.015625)
    const float norm        = delta / tick_span(slot);    // v50: span in 1/16 ticks
    out.charge = norm <= 1.0f ? 1.0f - std::fmax(norm, 0.0f) : 0.0f;
    out.ready  = out.charge >= 1.0f && !recharge_pending();
    out.color  = out.ready ? color_ready : color_notready;
    out.text   = "DT";
    out.icon   = out.ready ? "equipment/melee.vsvg_c"      // ready: knife icon per decomp
                           : "icons/ui/cancel.vsvg_c";     // not ready: cross
    return out;
}
