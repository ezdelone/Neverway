// ============================================================
// neverwin.dll — reconstructed source
// rage_weapon.h — runtime per-weapon state, shot records,
// shot history ring and the hit/miss resolver types
// Recovered from: struct layouts in sub_18047B4A0 (resolver),
// sub_180474680 (window), unk_180C3DF70 (cmd ring, 150 x 2000b)
// ============================================================
#pragma once
#include <cstdint>

struct vector { float x, y, z; };
struct qangle { float p, y, r; };
using pack64 = uint64_t;   // (tick:int32, frac:float) packed

// ---- per-cmd shot record ring (unk_180C3DF70, stride 2000, 150 slots)
struct shot_slot {
    int32_t  cmd;             // +0    slot cmd number, -1 = free
    int32_t  status;          // +4    (v25 != 2) + 1  -> 1 or 2
    int32_t  charge;          // +8    (dt charge steps; <=1 means "not ready")
    // +12.. unknown block (17-byte something via sub_180463B50)
    uint8_t  pad[1972];
};
static_assert(sizeof(shot_slot) == 2000);

// ---- weapon fire-window cache (layout used by sub_180474680)
// offsets are absolute into the weapon entity:
//   +852/+856 atk1 tick/frac, +860/+864 atk2, +1580 ring[32], +1836 count,
//   +1840 head, +348 next-attack pack, +884 shots-in-sequence
//   +1968 vdata ptr, +1976 weapon type u16

// ---- shot outcome record (resolver arg, ~328 bytes)
struct shot_record_t {
    uint32_t id;              // +0    (a1+0 -> sub_180470370 id)
    int32_t  target_idx;      // +8    (a1+2*4)
    int32_t  weapon_handle;   // +12   (a1+3*4)
    int32_t  hitgroup;        // +52   (a1+13*4) 0=head..8=generic
    float    hitchance;       // +300  (a1[75])
    int32_t  damage_dealt;    // +304  (a1[76])
    int32_t  damage_expected; // +340  (a1+85*4)
    int32_t  damage_target;   // +348  (a1+87*4)
    int32_t  pred_error_kind; // +324  (a1+81*4) 2 -> "aim punch"
    bool     rec_suppressed;  // +16   (a1+16) gate at fn start
    int32_t  status;          // +312  (a1+78*4)
    // reason flags
    bool     f_shootpos_mispred; // +317
    bool     f_lagcomp_mispred;  // +318
    bool     f_lagcomp_fail;     // +319
    bool     f_unknown;          // +316
    bool     f_spread_applied;   // +296
    bool     f_manual_shot;      // +297
    bool     f_force_shot;       // +321
    uint8_t  pad[?];
};

// status codes (switch in sub_18047B4A0):
enum shot_status : int {
    SHOT_HIT              = 1,  // logged via default branch ("hit")
    SHOT_PREDICTION       = 3,  // spread / hitchance misprediction / shootpos / aim punch
    SHOT_LAGCOMP          = 4,  // lagcomp misprediction / lagcomp failure / occlusion / unknown
    SHOT_EXTRAPOLATION    = 5,
    SHOT_DEATH            = 6,
    SHOT_PLAYER_DEATH     = 7,
    SHOT_EVENT_TIMEOUT    = 8,
    SHOT_UNREGISTERED     = 9,
    SHOT_DAMAGE_REJECTION = 10, // triggers forced DT recharge
};

static const char* kHitgroupName[9] = {
    "head", "chest", "stomach", "arm", "leg", "generic",
    // off_18089FAA0[0..8]; indices >= 8 -> "generic"
};
