// ============================================================
// neverwin.dll — reconstructed source
// remove_spread.cpp — deterministic spread solver
// Recovered from: sub_18042D730 (solve driver), sub_18042D5E0
// (pattern lookup fail path), sub_18042B640 (per-candidate loop,
// not fully dumped), sub_1804707A0 (config pack), engine callbacks
// ============================================================
#include "schema.h"
#include <cmath>
#include <cstdio>

namespace cfg { extern int remove_spread_mode; extern bool remove_spread; }

// ---- tier0 RNG (same stream the game uses) -----------------
using SetSeed_fn     = void(__fastcall*)(void* self, int seed);
using RandomFloat_fn = float(__fastcall*)(void* self, float lo, float hi);

static SetSeed_fn     rng_set_seed     = nullptr; // ?SetSeed@?$CUniformRandomStreamImpl@VCThreadNullMutex@@@@QEAAXH@Z
static RandomFloat_fn rng_random_float = nullptr; // ?RandomFloat@?$CUniformRandomStreamImpl@VCThreadNullMutex@@@@QEAAMMM@Z
static void*          rng_instance     = nullptr; // qword_1811118F0

// fallback: plain ran1 (as in the binary when tier0 exports are missing)
static float ran1_random(float lo, float hi);

static void init_rng()  // byte_180CD1AC6 latch
{
    static bool done = false;
    if (done) return;
    done = true;
    if (HMODULE tier0 = GetModuleHandleA("tier0.dll")) {
        rng_set_seed     = (SetSeed_fn)GetProcAddress(tier0,
            "?SetSeed@?$CUniformRandomStreamImpl@VCThreadNullMutex@@@@QEAAXH@Z");
        rng_random_float = (RandomFloat_fn)GetProcAddress(tier0,
            "?RandomFloat@?$CUniformRandomStreamImpl@VCThreadNullMutex@@@@QEAAMMM@Z");
        rng_instance     = nullptr; // original stores a stream object; we mirror the calls
    }
    solve_log("[solve] tier0 CUniformRandomStream %s",
        (rng_set_seed && rng_random_float) ? "ok" : "MISSING (plain ran1 used)");
}

// ---- spread-pattern engine scan ----------------------------
static uintptr_t g_pattern_table = 0;   // qword_1811118E0
static uintptr_t g_pattern_lookup = 0;  // qword_1811118E8

static bool scan_pattern_engine()  // byte_180CD1B2D latch, window from qword_180961CA8
{
    static bool done = false;
    if (done) return g_pattern_lookup != 0;
    done = true;

    uintptr_t base = module_base_window();          // qword_180961CA8
    if (!base) return false;
    for (uintptr_t p = base; p < base + 1536; ++p) {
        if (*(uint8_t*)p == 0x48 && *(uint8_t*)(p+1) == 0x8D && *(uint8_t*)(p+2) == 0x0D
            && *(uint8_t*)(p+7) == 0x45 && *(uint8_t*)(p+8) == 0x03
            && *(uint8_t*)(p+9) == 0xCC && *(uint8_t*)(p+10) == 0xE8)
        {
            g_pattern_table  = p + *(int32_t*)(p+3)  + 7;   // lea rcx, [rip+..]
            g_pattern_lookup = p + *(int32_t*)(p+11) + 15;  // second rip-rel target
            break;
        }
    }
    solve_log("[solve] spread pattern lookup %s", g_pattern_lookup ? "ok" : "NOT FOUND");
    return g_pattern_lookup != 0;
}

// ---- per-shot context --------------------------------------
struct spread_ctx {
    uint16_t item_def;        // a2
    int      shot_index;      // a3  (which bullet of the spray)
    uint32_t seed_base;       // from weapon + m_nNumBullets side data
    float    inaccuracy;      // from weapon vdata
    float    spread;          // from weapon vdata
    vector   shoot_pos;
    qangle   view_angles;
    int      num_pellets;     // m_nNumBullets (shotguns >1)
    uint32_t pattern_id;      // weapon+1952/1984 pair, clamped 0..1 select
    float    abs_scale;       // CGameSceneNode.m_flAbsScale (model scaling)
    // result
    qangle   solved_angles;
    bool     found;
};

// callbacks the candidate loop uses (mirror of v55[] in sub_18042D730)
struct solve_vtable {
    void*  self;
    void (*get_pattern_pos)(spread_ctx*, int pellet, vector* out); // sub_18042D5A0
    bool (*pattern_lookup)(spread_ctx*, int pellet, vector* out);  // sub_18042D5E0
    void (*advance_seed)(spread_ctx*);                            // sub_18042D660
    float(*pattern_spread)(spread_ctx*, int pellet);               // sub_18042D720
    void (*reset_seed)(spread_ctx*);                              // sub_18042D4E0
    bool (*next_candidate)(spread_ctx*);                          // sub_18042D510
};

// ---- pattern lookup with one-shot error latch (sub_18042D5E0)
static bool pattern_lookup(spread_ctx* c, int pellet, vector* out)
{
    if (g_pattern_lookup) {
        if (auto r = engine_pattern_lookup(c->pattern_id, c->shot_index, pellet, out))
            return r;
    }
    static bool complained = false;                 // byte_180CD1AC5
    c->found = false;
    if (!complained) {
        complained = true;
        solve_log("[solve] spread pattern lookup unavailable: "
                  "no Remove Spread shots with pattern pellets");
    }
    *out = {};                                      // a5=0, a6=0
    return false;
}

// ============================================================
// SOLVER DRIVER (sub_18042D730)
// Replays the game's RNG for the current shot and searches for
// the aim offset that cancels the sampled spread deviation.
//   mode 1 (Seed Check): verify the shot lands given hitchance
//   mode 2 (Full):       pick the direction with zero deviation
// ============================================================
bool solve_no_spread(spread_ctx* c, /*out*/ qangle* out_angles, int32_t* out_tick)
{
    if (!c->shot_index)
        return true;                                 // a2==0 -> nothing to do

    init_rng();
    offsets::init_ns_group();
    if (!scan_pattern_engine())
        return false;

    if (!rng_random_float) {                         // byte_180CD1AC7 one-shot
        static bool complained = false;
        if (!complained) { complained = true;
            solve_log("[solve] game seed function missing: no Remove Spread shots"); }
        return false;
    }

    // pull per-shot data off the weapon (mirrors the a4/a1 block reads)
    int num_bullets = 1;
    if (uintptr_t vdata = c->seed_base ? weapon_vdata(c->seed_base) : 0)
        if (offsets::m_nNumBullets)
            num_bullets = read_i32(vdata + offsets::m_nNumBullets);

    float abs_scale = 1.0f;
    if (offsets::m_pGameSceneNode && offsets::m_flAbsScale)
        if (auto node = read_ptr(c->seed_base, offsets::m_pGameSceneNode))
            abs_scale = read_f32(node, offsets::m_flAbsScale);

    // pellet center: avg of the pattern bounding box, scaled by model scale
    vector pellet_center = c->shoot_pos;
    pellet_center.x += ((c->pattern_bbox[3] + c->pattern_bbox[0]) * 0.5f) * abs_scale;
    pellet_center.y += ((c->pattern_bbox[4] + c->pattern_bbox[1]) * 0.5f) * abs_scale;
    pellet_center.z += ((c->pattern_bbox[5] + c->pattern_bbox[2]) * 0.5f) * abs_scale;
    const float pattern_radius = 0.5f * pattern_bbox_diagonal(c);

    // RNG mirror: seed the exact stream state for this (cmd, shot_index)
    int stream_seed = compute_shot_seed(c);          // from weapon+1940/1952/1984 group
    rng_set_seed(rng_instance, stream_seed);

    solve_vtable vt {
        c,
        cb_get_pattern_pos, cb_pattern_lookup, cb_advance_seed,
        cb_pattern_spread,  cb_reset_seed,     cb_next_candidate
    };

    int32_t solved_tick = 0;
    if (candidate_search(c, &vt, &solved_tick) /* sub_18042B640 */ && !c->aborted) {
        *out_angles = c->solved_angles;
        *out_tick   = solved_tick;
        return true;
    }
    return false;
}

// ============================================================
// CONFIG PACK (sub_1804707A0) — runtime per-weapon settings
// struct @ off_180C3AC98, built once per frame per active group
// ============================================================
struct rage_weapon_cfg {
    uint32_t group_id;        // v2[0]
    uint32_t history;         // v2[1]  <- dword_18095CD6C
    uint8_t  double_tap;      // +8     <- byte_18095CD7E
    uint8_t  automatic_fire;  // +9     <- byte_18095CD44
    uint8_t  min_stop_ticks;  // v2[8]  (derived from penetration slider)
    uint32_t aim_tick;        // v2[10]
    float    aim_fov;         // f11    dword_18095CD48 (limiters)
    float    aim_speed;       // f11    dword_18095CD4C
    float    reaction_time;   // f12    dword_18095CD50 / 1000
    float    kill_delay;      // f13    dword_18095CD54 / 1000
    uint32_t backtrack;       // v2[14] dword_18095CD5C
    uint32_t max_walls;       // v2[15] dword_18095CD58
    uint8_t  selftrack;       // +64    byte_18095CD60
    uint8_t  flags_unnamed;   // +17    byte_18095CD61 ? 0x80
    float    hitchance_scale; // f19
    uint8_t  scope_note;      // +81    byte_18091A190[...+271056]
    uint8_t  prefer_damage;   // +82
    uint8_t  prefer_hitchance;// +83
    uint8_t  extrapolation;   // +84
    uint8_t  duck_peek;       // +86    byte_18095CD7C
    uint32_t future_ticks;    // v2[22] dword_18095CD74
    uint8_t  delay_shot;      // +92    byte_18095CD70
    uint8_t  delay_shot_flag; // +93    byte_18095CD71
    uint8_t  double_precision;// +104   byte_18095CD7D
    uint32_t remove_spread_mode; // v2[24] dword_18095CD78 (gated by weapon vdata bit)
    uint32_t hitbox_mask;     // v2[25] built from the 64 toggles
};

void pack_weapon_cfg(rage_weapon_cfg* c)
{
    c->group_id       = current_group_id();
    c->history        = cfg::history;
    c->double_tap     = cfg::double_tap;
    c->automatic_fire = cfg::automatic_fire;

    if (!cfg::limiters) {
        c->aim_fov = 100; c->reaction_time = 0; c->kill_delay = 0;
        c->max_walls = 4; c->backtrack = 0; c->selftrack = 1;
        c->flags_unnamed = 0;
    } else {
        c->aim_fov       = (float)cfg::limiter_fov;
        c->aim_speed     = (float)cfg::limiter_speed;
        c->reaction_time = cfg::limiter_reaction / 1000.0f;
        c->kill_delay    = cfg::limiter_killdelay / 1000.0f;
        c->backtrack     = cfg::limiter_backtrack;
        c->max_walls     = cfg::limiter_max_walls;
        c->selftrack     = cfg::selftrack;
        c->flags_unnamed = cfg::unnamed_flag ? 0x80 : 0;
    }

    c->duck_peek      = cfg::duck_peek_assist;
    c->future_ticks   = cfg::future_ticks;
    c->delay_shot     = cfg::delay_shot;
    c->delay_shot_flag= cfg::delay_shot_b;
    c->double_precision = cfg::double_precision;

    // Remove Spread mode only applies when the active weapon vdata
    // reports the "has spread data" flag (v2[24] gate in the binary)
    c->remove_spread_mode = weapon_supports_spread_data() ? cfg::remove_spread_mode : 0;
    if (c->remove_spread_mode == 2 /* Full */) {
        // Full mode zeroes seed-dependent helpers (exact bytes in decomp):
        c->delay_shot_flag   = 0;
        c->prefer_hitchance  = 0;   // *((_WORD*)v2+40) = 0
        c->prefer_damage     = 0;   // +82
        c->history           = 0;   // (qword)(v2+5)=0 -> history+aim pair
        c->backtrack         = 0;   // v2[19]
    }
    c->hitbox_mask = build_hitbox_mask();   // the 0x1..0x40000 toggle cascade
}
