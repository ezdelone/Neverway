// ============================================================
// neverwin.dll — reconstructed source
// Module: schema.h — runtime schema offset resolver
// Recovered from: sub_18038EAF0 wrappers, cached in BSS globals
// ============================================================
#pragma once
#include <cstdint>

// The binary resolves every game offset at runtime through the
// game's schema system (class + property name -> field offset).
// Original: sub_18038EAF0(const char* klass, const char* prop)
uintptr_t schema_offset(const char* klass, const char* prop);

// one-shot caches (mirrors of the BSS latch bytes in the DLL)
namespace offsets {
    // resolved lazily, mirrors dword_181111C9C..CC8 (sub_18043B6A0)
    inline uintptr_t m_pWeaponServices;        // C_BasePlayerPawn
    inline uintptr_t m_hActiveWeapon;          // CPlayer_WeaponServices
    inline uintptr_t m_iShotsFired;            // C_CSPlayerPawn / Base
    inline uintptr_t m_angEyeAngles;           // C_CSPlayerPawn / Base
    inline uintptr_t m_nNextPrimaryAttackTick; // C_BasePlayerWeapon
    inline uintptr_t m_fAccuracyPenalty;       // C_CSWeaponBase
    inline uintptr_t m_fLastShotTime;          // C_CSWeaponBase
    inline uintptr_t m_nSubclassID;            // C_BaseEntity
    inline uintptr_t m_WeaponType;             // CCSWeaponBaseVData
    inline uintptr_t m_flCycleTime;            // CCSWeaponBaseVData
    inline uintptr_t m_nTickBase;              // CBasePlayerController
    inline uintptr_t v_angle;                  // C_BasePlayerPawn

    // DT tick-shift field group (sub_18026A790), mirrors dword_180CFA0FC..CFA10C
    inline uintptr_t dt_tickbase_field;        // pawn + off  : clamped tickbase
    inline uintptr_t dt_engine_time_field;     // weapon vdata side
    inline uintptr_t dt_subtick_field;         // secondary clamp target

    // weapon internals for the fire window (a1+ layout in sub_180474680)
    constexpr int WPN_TICK_HISTORY   = 1580;   // 32 x (tick,frac) pairs
    constexpr int WPN_TICK_HEAD      = 1840;
    constexpr int WPN_TICK_COUNT     = 1836;
    constexpr int WPN_ATK1_TICK      = 852;
    constexpr int WPN_ATK1_FRAC      = 856;
    constexpr int WPN_ATK2_TICK      = 860;
    constexpr int WPN_ATK2_FRAC      = 864;
    constexpr int WPN_NUM_BULLETS    = 1940;   // m_nNumBullets side copy
    constexpr int WPN_SHOT_IDX       = 1952;
    constexpr int WPN_SHOT_IDX2      = 1984;

    inline void init_weapon_group() { // == sub_18043B6A0
        if (!m_pWeaponServices) {
            m_pWeaponServices        = schema_offset("C_BasePlayerPawn",     "m_pWeaponServices");
            m_hActiveWeapon          = schema_offset("CPlayer_WeaponServices","m_hActiveWeapon");
            m_iShotsFired            = schema_offset("C_CSPlayerPawn",       "m_iShotsFired");
            if (!m_iShotsFired)
                m_iShotsFired      = schema_offset("C_CSPlayerPawnBase",   "m_iShotsFired");
            m_angEyeAngles           = schema_offset("C_CSPlayerPawn",       "m_angEyeAngles");
            if (!m_angEyeAngles)
                m_angEyeAngles     = schema_offset("C_CSPlayerPawnBase",   "m_angEyeAngles");
            m_nNextPrimaryAttackTick = schema_offset("C_BasePlayerWeapon",   "m_nNextPrimaryAttackTick");
            m_fAccuracyPenalty       = schema_offset("C_CSWeaponBase",       "m_fAccuracyPenalty");
            m_fLastShotTime          = schema_offset("C_CSWeaponBase",       "m_fLastShotTime");
            m_nSubclassID            = schema_offset("C_BaseEntity",         "m_nSubclassID");
            m_WeaponType             = schema_offset("CCSWeaponBaseVData",   "m_WeaponType");
            m_flCycleTime            = schema_offset("CCSWeaponBaseVData",   "m_flCycleTime");
            m_nTickBase              = schema_offset("CBasePlayerController","m_nTickBase");
            v_angle                  = schema_offset("C_BasePlayerPawn",     "v_angle");
        }
    }

    // NS solver group, mirrors dword_1811118D4..D0/CC (sub_18042D730)
    inline uintptr_t m_nNumBullets;            // CCSWeaponBaseVData
    inline uintptr_t m_pGameSceneNode;         // C_BaseEntity
    inline uintptr_t m_flAbsScale;             // CGameSceneNode

    inline void init_ns_group() {
        if (!m_nNumBullets) {
            m_nNumBullets   = schema_offset("CCSWeaponBaseVData", "m_nNumBullets");
            m_pGameSceneNode= schema_offset("C_BaseEntity",       "m_pGameSceneNode");
            m_flAbsScale    = schema_offset("CGameSceneNode",     "m_flAbsScale");
        }
    }
}
