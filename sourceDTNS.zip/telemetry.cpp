// ============================================================
// neverwin.dll — reconstructed source
// telemetry.cpp — wl_shots.log / wl_perf.log writers
// Recovered from: sub_18046E7D0 (wl_shots), sub_18020E390 +
// sub_18020EEB0 (perf/jitter monitors)
// ============================================================
#include <cstdio>
#include <cstdint>

// ---- wl_shots.log (sub_18046E7D0) ---------------------------
// One F line per fired rage shot, one R line when resolved (same cmd).
// 2 MB cap per session, then stops logging.
static FILE*  shots_fp        = nullptr;
static int32_t shots_bytes    = 0;
static bool   shots_cap_hit   = false;
static bool   shots_header_done = false;

void wl_shots_log(const char* line)
{
    if (shots_cap_hit) return;
    if (!shots_header_done) {
        shots_header_done = true;
        const char* header =
            "# wl_shots.log (one F line per fired rage gun shot, one R line when it is resolved; same cmd)\n"
            "# F cmd | snap rec|pred (record tick, pred = status <= 1 or forced re-prediction of cmd - 1,\n"
            "#   live m_nTickBase, |live eye - record eye|, game ran this cmd already)\n"
            "#   | tb local tickbase / record tick | stepped tb | T stamp of the origin [perm]\n"
            "#   | off W+0x40C s (ticks) | q = T - off (ring query) covered 0 snapshot eye / 1 ring\n"
            "#   | ring n [oldest .. newest] (server-equivalent) game n oldest (the client's own ring)\n"
            "#   | org origin used | old eye with off 0 (d) | end stepped eye (d) | base command-snapshot eye (d)\n"
            "#   | live eye at createmove (d) | snap origin / velocity (stepped)\n"
            "#   | hist idx/count player tick+frac render tick+frac attack1/attack2\n"
            "#   | tgt record tick hg dmg\n"
            "# R cmd | status | impacts n | proj |proj - origin| moved 0/1\n"
            "#   | perp distance of org / old / end / base / live to the impact line\n"
            "#   | hurt hg dmg | reason\n";
        file_append("wl_shots.log", header);
        shots_bytes += (int)strlen(header);
    }
    file_append("wl_shots.log", "%s", line);
    shots_bytes += (int)strlen(line) + 1;
    if (shots_bytes >= 0x200000) {
        file_append("wl_shots.log", "# wl_shots.log: 2 MB cap reached, logging stopped for this session");
        shots_cap_hit = true;
    }
}

// ---- local JITTER monitor (sub_18020E390) --------------------
// Per-frame movement sanity of the local pawn. Classifies each frame:
//   stall / backstep / jump / nodeToWorld!=absorigin / yaw-flip /
//   tickbase-jump / simtime-jump / camera-flip
struct jitter_stats {
    int32_t frames, moving;
    int32_t stalls, backsteps, jumps;
    int32_t node_to_world_mismatch;
    int32_t yaw_flips;
    int32_t tickbase_jumps, simtime_jumps, camera_flips;
    int32_t dropped_details;
    float   frame_ms_max;
    vector  last_origin;
    float   last_abs_yaw, last_eye_yaw, last_cam_yaw;
    int32_t last_tickbase;
    float   last_simtime;
    bool    primed;
};

static jitter_stats J;

void jitter_frame_tick(double dt, pawn_snapshot_t* snap)
{
    if (!snap->valid || dt <= 0.0 || dt > 0.1)
        return;

    vector move = snap->origin - J.last_origin;
    float  dist = move.length();
    float  speed = snap->velocity.length2d();
    float  expected = dt * speed;

    int   tb_delta  = snap->tickbase - J.last_tickbase;
    float st_delta  = (snap->simtime - J.last_simtime) * 64.0f;
    int   max_ticks = game_max_ticks();

    float eye_dyaw = angle_diff_deg(snap->eye_yaw, J.last_eye_yaw);
    float cam_dyaw = angle_diff_deg(snap->cam_yaw, J.last_cam_yaw);
    bool  camera_flip = fabsf(eye_dyaw) > 5 && fabsf(J.last_eye_yaw) > 5
                      && (snap->eye_yaw * cam_dyaw) < 0.0f;

    const char* reason = nullptr;
    if (snap->node_to_world_offset().length() > 0.05f) {
        ++J.node_to_world_mismatch; reason = "nodeToWorld!=absorigin";
    }
    if (speed < 40.0f) {
        // near-stationary: anything above 4 units is a jump
        if (!(dist <= 4.0f)) { ++J.jumps; reason = reason ?: "jump"; }
    } else {
        ++J.moving;
        float fwd = -0.05f * expected - 0.1f;
        float proj = (move.x * snap->velocity.x + move.y * snap->velocity.y) / speed;
        if (fwd > proj) { ++J.backsteps; reason = "backstep"; }
        else if (0.15f * expected > dist) { ++J.stalls; reason = "stall"; }
        else if (!(dist <= 2.5f * expected + 0.5f)) { ++J.jumps; reason = "jump"; }
    }

    if (fabsf(eye_dyaw) > 45.0f) { ++J.yaw_flips; reason = reason ?: "yaw-flip"; }
    if (tb_delta < 0 || tb_delta > max_ticks + 2) { ++J.tickbase_jumps; reason = "tickbase-jump"; }
    if (st_delta < -0.5f || st_delta > (float)max_ticks + 2) { ++J.simtime_jumps; reason = "simtime-jump"; }
    if (camera_flip) { ++J.camera_flips; reason = "camera-flip"; }

    if (reason && J.dropped_details < 6) {
        ++J.frames ? 0 : 0; // counters ticked below
        wl_perf_log(
            "[%llu] local JITTER %s | frame %.2f ms | step %.2f expected %.2f speed %.0f"
            " | nodeToWorld-abs %.2f | abs yaw %.1f (%+.1f) eye yaw %.1f (%+.1f)"
            " camera yaw %.1f (%+.1f) aa turned %d | tickbase %+d simtime %+.2f ticks"
            " (frame %d) | packets %d re-predictions %d\n",
            GetTickCount64(), reason, dt * 1000.0, dist, expected, speed,
            snap->node_to_world_offset().length(),
            snap->abs_yaw, eye_dyaw, snap->eye_yaw, eye_dyaw,
            snap->cam_yaw, cam_dyaw, snap->aa_turned != 0,
            tb_delta, st_delta, frame_counter(),
            packets_this_frame(), repredictions_this_frame());
    }

    // latch current state for next frame
    J.last_origin    = snap->origin;
    J.last_abs_yaw   = snap->abs_yaw;
    J.last_eye_yaw   = snap->eye_yaw;
    J.last_cam_yaw   = snap->cam_yaw;
    J.last_tickbase  = snap->tickbase;
    J.last_simtime   = snap->simtime;
    J.frame_ms_max   = std::max(J.frame_ms_max, dt * 1000.0);
    ++J.frames;
    if (speed >= 40.0f) ++J.moving;
    J.primed = true;
}

// ---- per-second summary (sub_18020EEB0 tail) ----------------
void jitter_summary_tick()
{
    static uint64_t last_flush = 0, last_activity = 0;
    uint64_t now = GetTickCount64();
    if (now - last_flush < 1000) return;

    int anomalies = J.backsteps + J.jumps + J.tickbase_jumps
                  + J.simtime_jumps + J.camera_flips + J.yaw_flips
                  + J.stalls + J.node_to_world_mismatch;
    if (now - last_activity >= 30000) {          // 30 s idle -> summary only
        if (anomalies)
            wl_perf_log(
                "[%llu] local JITTER summary | frames %d moving %d | stalls %d backsteps %d"
                " jumps %d | nodeToWorld != absorigin %d | yaw flips %d | tickbase jumps %d"
                " | simtime jumps %d | camera yaw back-and-forth %d | detail lines dropped %d\n",
                now, J.frames, J.moving, J.stalls, J.backsteps, J.jumps,
                J.node_to_world_mismatch, J.yaw_flips, J.tickbase_jumps,
                J.simtime_jumps, J.camera_flips, J.dropped_details);
        J = {};
        last_flush = now;
    }
}
